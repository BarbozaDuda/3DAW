function cadastroperg(){
    var perg = []
    for (var i = 0; i < 1; i++){
        times.push(prompt('Digite a pergunta: '))
    }
    return times
}
function alteracaoDadosperg(){

    var times = cadastroperg()
    var time = prompt('Digite o nome da pergunta que deseja alterar: ')
    var indice = index.html(time)
    if (indice == -1){
        alert('pergunta não encontrada')
    }else{
        var novaperg = prompt('Digite a nova pergunta: ')
        times[indice] = novoTime
    }
    return times
}
