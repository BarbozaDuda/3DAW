<!DOCTYPE html>
<html>
<head>
  <link href="index.html"/>
  <meta charset="utf-8">
   <link href="index.html"> 
  <title>3daw</title>
</head>
  
<body>
<div>
  
<?php 
include("index.html");
$nome=$_GET["nome"];
$ano=$_GET["ano"];
$idade=date("Y")-$ano;
echo "$nome e $sexo e tem $idade anos.";
?>
<a href="index.html"> Voltar </a>
</div> 
</body>
</html>